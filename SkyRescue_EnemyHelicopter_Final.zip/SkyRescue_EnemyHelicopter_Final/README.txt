SKY RESCUE - CHECKPOINT 3 MODIFIED VERSION

Changes made:
1. Sector 3 final enemy is now an ENEMY HELICOPTER instead of the Storm Commander Titan.
2. The old boss system is renamed internally to EnemyHelicopter/EnemyProjectile so there is no BossVillain/boss object in the modified files.
3. Enemy helicopter moves around Sector 3 and fires homing projectiles at the player.
4. Player bullets and EMP/Sky Blast can damage the enemy helicopter.
5. Sector 3 buildings are lowered.
6. Dynamic Sector 3 building regeneration is also limited to shorter heights.
7. Sector 3 now requires BOTH the rescue quota AND enemy helicopter defeat before Victory.
8. Fixed duplicate careerMissionsCompleted increment on final-sector completion.
9. Fixed loadGameProgress() so saved level, sector and score are restored.
10. Added imgEnemyHelicopter with fallback to the normal helicopter image.

ASSET:
For a distinct enemy helicopter, add:
    enemy_helicopter.png
or:
    Images/enemy_helicopter.png

The code will fall back to helicopter.png if the enemy sprite is not found, so the project still runs.

IMPORTANT:
Replace the corresponding files in your Visual Studio project with the files in this folder.
Then Build -> Rebuild Solution.
