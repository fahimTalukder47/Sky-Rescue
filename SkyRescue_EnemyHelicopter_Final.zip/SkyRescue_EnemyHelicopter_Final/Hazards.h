#ifndef HAZARDS_H
#define HAZARDS_H

#include "Variables.h"
#include "Leaderboard.h"

inline void shootBullet() {
	if (countdownTimer > 0) return;

	for (int b = 0; b < MAX_BULLETS; b++) {
		if (!bullets[b].active) {
			bullets[b].active = true;
			bullets[b].x = player.x + 35.0;
			bullets[b].y = player.y - 4.0;
			bullets[b].vx = 11.0;
			playSoundEffect("shoot");
			break;
		}
	}
}

inline void activateSkyBlast() {
	if (countdownTimer > 0) return;

	if (player.spells > 0 && !shockwave.active) {
		player.spells--;
		shockwave.active = true;
		shockwave.x = player.x;
		shockwave.y = player.y;
		shockwave.radius = 20.0;
		shockwave.maxRadius = 450.0;
		player.isShielded = true;
		player.shieldTimer = 360;
		player.fuel = (player.fuel + 30.0 > 100.0) ? 100.0 : player.fuel + 30.0;
		for (int i = 0; i < MAX_OBSTACLES; i++) {
			if (obstacles[i].active) {
				obstacles[i].active = false;
				score += 50;
			}
		}
		playSoundEffect("spell");
	}
}

// Safe Damage Handling with 3-Lives System (Professor Req)
inline void playerTakeDamage(int reason) {
	if (player.isShielded) return;
	player.lives--;
	playSoundEffect("life_lost");
	if (player.lives > 0) {
		player.isShielded = true;
		player.shieldTimer = 180; // 3 seconds invulnerability
		player.vy = 2.4; // Safe bounce
		sprintf_s(rescueNotificationText, "WARNING! DAMAGE TAKEN! %d LIVES REMAINING!", player.lives);
		rescueNotificationTimer = 90;
	}
	else {
		player.lives = 0;
		gameOverReason = reason;
		updateHighScore(score);
		saveGameProgress();
		playSoundEffect("crash");
		currentState = GAMEOVER;
	}
}

// Sector 3 Enemy Helicopter AI & Combat Logic
inline void updateEnemyHelicopter() {
	if (!enemyHelicopter.active || currentSector != 3) return;

	if (enemyHelicopter.flashTimer > 0) enemyHelicopter.flashTimer--;

	// Enemy helicopter patrol across the Sector 3 skyline
	enemyHelicopter.x += enemyHelicopter.vx;
	enemyHelicopter.y += enemyHelicopter.vy;

	if (enemyHelicopter.x < cameraX + 320.0) {
		enemyHelicopter.x = cameraX + 320.0;
		enemyHelicopter.vx = 2.2 + (selectedLevelTier * 0.4);
	}
	else if (enemyHelicopter.x > cameraX + SCREEN_WIDTH - 80.0) {
		enemyHelicopter.x = cameraX + SCREEN_WIDTH - 80.0;
		enemyHelicopter.vx = -(2.2 + (selectedLevelTier * 0.4));
	}

	if (enemyHelicopter.y < 320.0) {
		enemyHelicopter.y = 320.0;
		enemyHelicopter.vy = 0.8;
	}
	else if (enemyHelicopter.y > SCREEN_HEIGHT - 100.0) {
		enemyHelicopter.y = SCREEN_HEIGHT - 100.0;
		enemyHelicopter.vy = -0.8;
	}

	// Enemy helicopter fires homing missiles
	enemyHelicopter.shootTimer++;
	int fireInterval = 105 - (selectedLevelTier * 15);
	if (fireInterval < 45) fireInterval = 45;

	if (enemyHelicopter.shootTimer >= fireInterval) {
		enemyHelicopter.shootTimer = 0;
		for (int p = 0; p < MAX_ENEMY_PROJECTILES; p++) {
			if (!enemyHelicopter.projectiles[p].active) {
				enemyHelicopter.projectiles[p].active = true;
				enemyHelicopter.projectiles[p].x = enemyHelicopter.x - enemyHelicopter.width * 0.45;
				enemyHelicopter.projectiles[p].y = enemyHelicopter.y - 5.0;
				double dx = player.x - enemyHelicopter.projectiles[p].x;
				double dy = player.y - enemyHelicopter.projectiles[p].y;
				double len = sqrt(dx * dx + dy * dy);
				if (len > 0.0) {
					enemyHelicopter.projectiles[p].vx = (dx / len) * 5.0;
					enemyHelicopter.projectiles[p].vy = (dy / len) * 5.0;
				}
				else {
					enemyHelicopter.projectiles[p].vx = -4.0;
					enemyHelicopter.projectiles[p].vy = 0.0;
				}
				playSoundEffect("shoot");
				break;
			}
		}
	}

	// Enemy Projectiles movement and collision
	for (int p = 0; p < MAX_ENEMY_PROJECTILES; p++) {
		if (enemyHelicopter.projectiles[p].active) {
			enemyHelicopter.projectiles[p].x += enemyHelicopter.projectiles[p].vx;
			enemyHelicopter.projectiles[p].y += enemyHelicopter.projectiles[p].vy;

			double pDist = sqrt(pow(enemyHelicopter.projectiles[p].x - player.x, 2) + pow(enemyHelicopter.projectiles[p].y - player.y, 2));
			if (pDist < 28.0) {
				enemyHelicopter.projectiles[p].active = false;
				playerTakeDamage(0);
			}

			if (enemyHelicopter.projectiles[p].x < cameraX - 50.0 || enemyHelicopter.projectiles[p].x > cameraX + SCREEN_WIDTH + 50.0 ||
				enemyHelicopter.projectiles[p].y < 0.0 || enemyHelicopter.projectiles[p].y > SCREEN_HEIGHT) {
				enemyHelicopter.projectiles[p].active = false;
			}
		}
	}

	// EMP shockwave damage to enemy helicopter
	if (shockwave.active) {
		double sDist = sqrt(pow(enemyHelicopter.x - shockwave.x, 2) + pow(enemyHelicopter.y - shockwave.y, 2));
		if (sDist <= shockwave.radius + 30.0 && enemyHelicopter.flashTimer == 0) {
			enemyHelicopter.hp -= 2;
			enemyHelicopter.flashTimer = 15;
			score += 100;
			playSoundEffect("enemy_hit");
			if (enemyHelicopter.hp <= 0) {
				enemyHelicopter.hp = 0;
				enemyHelicopter.active = false;
				score += 600;
				careerMissionsCompleted++;
				saveGameProgress();
				playSoundEffect("enemy_defeat");
				sprintf_s(rescueNotificationText, "ENEMY HELICOPTER DESTROYED! +600 PTS!");
				rescueNotificationTimer = 120;
			}
		}
	}
}

inline void updateObstaclesAndPickups() {
	if (countdownTimer > 0) return;

	updateEnemyHelicopter();

	if (shockwave.active) {
		shockwave.radius += 12.0;
		if (shockwave.radius >= shockwave.maxRadius) {
			shockwave.active = false;
		}
	}

	if (player.isShielded) {
		player.shieldTimer--;
		if (player.shieldTimer <= 0) {
			player.isShielded = false;
		}
	}

	for (int b = 0; b < MAX_BULLETS; b++) {
		if (bullets[b].active) {
			bullets[b].x += bullets[b].vx;

			// Check bullet hits enemy helicopter
			if (enemyHelicopter.active && currentSector == 3) {
				double bDist = sqrt(pow(bullets[b].x - enemyHelicopter.x, 2) + pow(bullets[b].y - enemyHelicopter.y, 2));
				if (bDist < 55.0) {
					bullets[b].active = false;
					enemyHelicopter.hp--;
					enemyHelicopter.flashTimer = 12;
					score += 40;
					playSoundEffect("enemy_hit");
					if (enemyHelicopter.hp <= 0) {
						enemyHelicopter.hp = 0;
						enemyHelicopter.active = false;
						score += 600;
						careerMissionsCompleted++;
						saveGameProgress();
						playSoundEffect("enemy_defeat");
						sprintf_s(rescueNotificationText, "ENEMY HELICOPTER DESTROYED! +600 PTS! COMPLETE THE RESCUE!");
						rescueNotificationTimer = 120;
					}
					continue;
				}
			}

			for (int i = 0; i < MAX_OBSTACLES; i++) {
				if (obstacles[i].active) {
					double dist = sqrt(pow(bullets[b].x - obstacles[i].x, 2) + pow(bullets[b].y - obstacles[i].y, 2));
					if (dist < 26.0) {
						obstacles[i].active = false;
						bullets[b].active = false;
						score += 60;
						playSoundEffect("hit");
						sprintf_s(rescueNotificationText, "+60 PTS! HAZARD DESTROYED!");
						rescueNotificationTimer = 65;
						break;
					}
				}
			}

			if (bullets[b].x > cameraX + SCREEN_WIDTH + 100.0) bullets[b].active = false;
		}
	}

	for (int i = 0; i < MAX_OBSTACLES; i++) {
		if (obstacles[i].active) {
			obstacles[i].x += obstacles[i].vx;
			obstacles[i].y += obstacles[i].vy;
			obstacles[i].param += 0.05;
			if (obstacles[i].type == OBS_BIRD) {
				obstacles[i].y += sin(obstacles[i].param) * 1.2;
			}
			if (shockwave.active) {
				double sDist = sqrt(pow(obstacles[i].x - shockwave.x, 2) + pow(obstacles[i].y - shockwave.y, 2));
				if (sDist <= shockwave.radius) {
					obstacles[i].active = false;
					score += 40;
					continue;
				}
			}
			double dist = sqrt(pow(obstacles[i].x - player.x, 2) + pow(obstacles[i].y - player.y, 2));
			if (dist < 26.0) {
				if (player.isShielded) {
					obstacles[i].active = false;
					score += 30;
				}
				else {
					obstacles[i].active = false;
					playerTakeDamage(0);
					if (currentState == GAMEOVER) return;
				}
			}
			if (obstacles[i].x < cameraX - 100.0 || obstacles[i].x > cameraX + SCREEN_WIDTH + 120.0 || obstacles[i].y < -40.0) {
				obstacles[i].active = false;
			}
		}
	}

	for (int f = 0; f < 3; f++) {
		if (fuelPickups[f].active) {
			fuelPickups[f].y -= fuelPickups[f].vy;
			double fDist = sqrt(pow(fuelPickups[f].x - player.x, 2) + pow(fuelPickups[f].y - player.y, 2));
			if (fDist < 42.0) {
				player.fuel = (player.fuel + 40.0 > 100.0) ? 100.0 : player.fuel + 40.0;
				fuelPickups[f].active = false;
				playSoundEffect("refuel");
			}
			if (fuelPickups[f].y < 40) fuelPickups[f].active = false;
		}
	}
	for (int s = 0; s < 2; s++) {
		if (spellPickups[s].active) {
			spellPickups[s].y -= spellPickups[s].vy;
			spellPickups[s].pulse += 0.1;
			double sDist = sqrt(pow(spellPickups[s].x - player.x, 2) + pow(spellPickups[s].y - player.y, 2));
			if (sDist < 42.0) {
				player.spells++;
				spellPickups[s].active = false;
				playSoundEffect("refuel");
			}
			if (spellPickups[s].y < 40) spellPickups[s].active = false;
		}
	}
}

inline void updateHazardSpawns() {
	if (countdownTimer > 0) return;

	double speedMult = 1.0 + (selectedLevelTier - 1) * 0.40;
	int maxActive = selectedLevelTier + (currentSector > 1 ? 1 : 0);
	int currentActive = 0;
	for (int i = 0; i < MAX_OBSTACLES; i++) {
		if (obstacles[i].active) currentActive++;
	}

	if (currentActive < maxActive && rand() % 100 < 35) {
		for (int i = 0; i < MAX_OBSTACLES; i++) {
			if (!obstacles[i].active) {
				obstacles[i].active = true;
				obstacles[i].param = 0;
				obstacles[i].spriteVariant = rand() % 2;

				if (currentSector == 1) {
					obstacles[i].type = OBS_BIRD;
					obstacles[i].x = cameraX + SCREEN_WIDTH + 25.0;
					obstacles[i].y = 170 + (rand() % 280);
					obstacles[i].vx = -(1.5 + ((rand() % 5) / 10.0)) * speedMult;
					obstacles[i].vy = 0;
					obstacles[i].width = 22;
				}
				else if (currentSector == 2) {
					if (rand() % 2 == 0) {
						obstacles[i].type = OBS_ROCK;
						obstacles[i].x = cameraX + 150.0 + (rand() % (SCREEN_WIDTH - 250));
						obstacles[i].y = SCREEN_HEIGHT + 15;
						obstacles[i].vx = -(0.6 + ((rand() % 5) / 10.0)) * speedMult;
						obstacles[i].vy = -(2.0 + ((rand() % 7) / 10.0)) * speedMult;
						obstacles[i].width = 24;
					}
					else {
						obstacles[i].type = OBS_BIRD;
						obstacles[i].x = cameraX + SCREEN_WIDTH + 25.0;
						obstacles[i].y = 150 + (rand() % 290);
						obstacles[i].vx = -(1.8 + ((rand() % 5) / 10.0)) * speedMult;
						obstacles[i].vy = 0;
						obstacles[i].width = 22;
					}
				}
				else {
					if (rand() % 2 == 0) {
						obstacles[i].type = OBS_DRONE;
						obstacles[i].x = cameraX + SCREEN_WIDTH + 25.0;
						obstacles[i].y = 160 + (rand() % 290);
						obstacles[i].vx = -(2.2 + ((rand() % 7) / 10.0)) * speedMult;
						obstacles[i].vy = 0;
						obstacles[i].width = 26;
					}
					else {
						obstacles[i].type = OBS_LIGHTNING;
						obstacles[i].x = cameraX + 180.0 + (rand() % (SCREEN_WIDTH - 280));
						obstacles[i].y = SCREEN_HEIGHT - 90;
						obstacles[i].vx = -0.8 * speedMult;
						obstacles[i].vy = 0;
						obstacles[i].width = 30;
					}
				}
				break;
			}
		}
	}

	int activeFuel = 0;
	for (int f = 0; f < 3; f++) if (fuelPickups[f].active) activeFuel++;

	if (activeFuel == 0 && (player.fuel < 70.0 || (rand() % 100 < 2))) {
		for (int f = 0; f < 3; f++) {
			if (!fuelPickups[f].active) {
				fuelPickups[f].active = true;
				fuelPickups[f].x = cameraX + 180.0 + (rand() % (SCREEN_WIDTH - 320));
				fuelPickups[f].y = SCREEN_HEIGHT - 45;
				fuelPickups[f].vy = 1.1;
				fuelPickups[f].hasParachute = true;
				fuelPickups[f].spriteVariant = rand() % 2;
				break;
			}
		}
	}

	int activeSpells = 0;
	for (int s = 0; s < 2; s++) if (spellPickups[s].active) activeSpells++;

	if (activeSpells == 0 && player.spells <= 1 && (rand() % 100 < 1)) {
		for (int s = 0; s < 2; s++) {
			if (!spellPickups[s].active) {
				spellPickups[s].active = true;
				spellPickups[s].x = cameraX + 200.0 + (rand() % (SCREEN_WIDTH - 350));
				spellPickups[s].y = SCREEN_HEIGHT - 55;
				spellPickups[s].vy = 0.9;
				spellPickups[s].pulse = 0;
				spellPickups[s].spriteVariant = rand() % 2;
				break;
			}
		}
	}

	if (currentSector == 3 && rand() % 100 < (selectedLevelTier * 5)) {
		lightningFlash = 3;
	}
	else if (lightningFlash > 0) {
		lightningFlash--;
	}
}

#endif 